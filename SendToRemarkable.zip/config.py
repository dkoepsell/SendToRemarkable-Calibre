from calibre.utils.config import JSONConfig
from qt.core import (
    QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QGroupBox, QMessageBox,
)

prefs = JSONConfig('plugins/send_to_remarkable')
prefs.defaults['device_token'] = ''

_REG_URL = 'https://webapp-prod.cloud.remarkable.engineering/token/json/2/device/new'


def _post_json(url, payload_dict, max_redirects=8):
    """POST JSON via http.client, manually following redirects with POST preserved."""
    import http.client, json, ssl, urllib.parse

    body    = json.dumps(payload_dict).encode('utf-8')
    headers = {
        'Content-Type':   'application/json',
        'Authorization':  'Bearer',
        'User-Agent':     'reMarkable Desktop/3.0.1.5',
        'Content-Length': str(len(body)),
    }
    ctx = ssl.create_default_context()

    for _ in range(max_redirects):
        p    = urllib.parse.urlparse(url)
        path = (p.path or '/') + ('?' + p.query if p.query else '')
        conn = http.client.HTTPSConnection(p.netloc, context=ctx, timeout=25)
        try:
            conn.request('POST', path, body=body, headers=headers)
            r      = conn.getresponse()
            status = r.status
            loc    = r.getheader('Location', '')
            data   = r.read().decode('utf-8', errors='replace').strip()
        finally:
            conn.close()

        if status == 200:
            return data
        if status in (301, 302, 303, 307, 308) and loc:
            url = urllib.parse.urljoin(url, loc)
            # Keep POST + body on all redirect types (server expectation)
            continue
        raise RuntimeError('HTTP {}: {}'.format(status, data or '(empty body)'))

    raise RuntimeError('Too many redirects')


class ConfigWidget(QWidget):

    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setSpacing(12)

        info = QLabel(
            '<b>First-time setup:</b><br>'
            '1. Log into <a href="https://my.remarkable.com">my.remarkable.com</a>.<br>'
            '2. Visit <a href="https://my.remarkable.com/device/browser/connect">'
            'my.remarkable.com/device/browser/connect</a>.<br>'
            '3. Copy the 8-character one-time code and paste it below.<br>'
            '<i>Note: each code is single-use — generate a fresh one per attempt.</i>'
        )
        info.setWordWrap(True)
        info.setOpenExternalLinks(True)
        layout.addWidget(info)

        reg_group  = QGroupBox('Device Registration')
        reg_layout = QVBoxLayout(reg_group)

        row = QHBoxLayout()
        row.addWidget(QLabel('One-time code:'))
        self.code_edit = QLineEdit()
        self.code_edit.setPlaceholderText('e.g. abcdefgh')
        self.code_edit.setMaxLength(16)
        row.addWidget(self.code_edit)
        reg_layout.addLayout(row)

        self.reg_btn = QPushButton('Register Device')
        self.reg_btn.clicked.connect(self._register)
        reg_layout.addWidget(self.reg_btn)

        self.status = QLabel('')
        self.status.setWordWrap(True)
        reg_layout.addWidget(self.status)
        layout.addWidget(reg_group)

        tok_group  = QGroupBox('Stored Device Token')
        tok_layout = QVBoxLayout(tok_group)

        self.token_display = QLineEdit()
        self.token_display.setReadOnly(True)
        try:
            self.token_display.setEchoMode(QLineEdit.EchoMode.Password)
        except AttributeError:
            self.token_display.setEchoMode(QLineEdit.Password)
        self.token_display.setPlaceholderText('(not registered yet)')
        tok_layout.addWidget(self.token_display)

        clear_btn = QPushButton('Clear Token')
        clear_btn.clicked.connect(self._clear)
        tok_layout.addWidget(clear_btn)

        layout.addWidget(tok_group)
        layout.addStretch()

        existing = prefs['device_token']
        if existing:
            self.token_display.setText(existing)
            self._set_status('\u2713 Device already registered.', 'green')

    def _set_status(self, msg, color=''):
        self.status.setText(msg)
        self.status.setStyleSheet('color: {};'.format(color) if color else '')

    def _register(self):
        code = self.code_edit.text().strip()
        if len(code) < 8:
            QMessageBox.warning(self, 'Missing code',
                'Enter the 8-character one-time code from the reMarkable website.')
            return
        self.reg_btn.setEnabled(False)
        self._set_status('Registering\u2026')
        try:
            import uuid
            token = _post_json(_REG_URL, {
                'code':       code,
                'deviceDesc': 'browser-chrome',
                'deviceID':   str(uuid.uuid4()),
            })
            if token:
                prefs['device_token'] = token
                self.token_display.setText(token)
                self._set_status('\u2713 Registered! Token saved.', 'green')
                self.code_edit.clear()
            else:
                self._set_status('\u2717 Server returned empty token.', 'red')
        except Exception as exc:
            self._set_status('\u2717 {}'.format(exc), 'red')
        finally:
            self.reg_btn.setEnabled(True)

    def _clear(self):
        prefs['device_token'] = ''
        self.token_display.clear()
        self._set_status('Token cleared.', 'darkorange')

    def save_settings(self):
        pass
