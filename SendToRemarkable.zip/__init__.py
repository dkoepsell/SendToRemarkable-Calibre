from calibre.customize import InterfaceActionBase

class SendToRemarkablePlugin(InterfaceActionBase):
    name                    = 'Send to reMarkable'
    description             = 'Send selected EPUB books to your reMarkable tablet via the cloud'
    supported_platforms     = ['windows', 'osx', 'linux']
    author                  = 'David Koepsell'
    version                 = (1, 0, 0)
    minimum_calibre_version = (5, 0, 0)
    actual_plugin           = 'calibre_plugins.send_to_remarkable.action:SendToRemarkableAction'

    def is_customizable(self):
        return True

    def config_widget(self):
        from calibre_plugins.send_to_remarkable.config import ConfigWidget
        return ConfigWidget()

    def save_settings(self, config_widget):
        config_widget.save_settings()
        ac = self.actual_plugin_
        if ac is not None and hasattr(ac, 'apply_settings'):
            ac.apply_settings()
