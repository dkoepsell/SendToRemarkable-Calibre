import os, io, json, uuid, time, ssl, zipfile, tempfile, base64
import http.client, urllib.parse

from calibre.gui2.actions import InterfaceAction

AUTH_HOST   = 'webapp-prod.cloud.remarkable.engineering'
UPLOAD_HOST = 'internal.cloud.remarkable.com'


def _post(host, path, body=b'', headers=None, max_redirects=8):
    """POST via http.client, following redirects while preserving POST+body."""
    ctx = ssl.create_default_context()
    hdrs = headers or {}
    hdrs.setdefault('Content-Length', str(len(body)))

    current_host = host
    current_path = path

    for _ in range(max_redirects):
        conn = http.client.HTTPSConnection(current_host, context=ctx, timeout=30)
        try:
            conn.request('POST', current_path, body=body, headers=hdrs)
            r      = conn.getresponse()
            status = r.status
            loc    = r.getheader('Location', '')
            data   = r.read()
        finally:
            conn.close()

        if status == 200:
            return data
        if status in (301, 302, 303, 307, 308) and loc:
            p = urllib.parse.urlparse(loc)
            current_host = p.netloc or current_host
            current_path = (p.path or '/') + ('?' + p.query if p.query else '')
            hdrs['Host'] = current_host
            continue
        raise RuntimeError('HTTP {}: {}'.format(
            status, data.decode('utf-8', errors='replace').strip() or '(empty body)'))

    raise RuntimeError('Too many redirects')


def rm_user_token(device_token):
    """Exchange device token for a short-lived user token."""
    data = _post(
        AUTH_HOST,
        '/token/json/2/user/new',
        body=b'',
        headers={
            'Authorization': 'Bearer ' + device_token,
            'User-Agent':    'reMarkable Desktop/3.0.1.5',
            'Content-Length': '0',
        },
    )
    return data.decode('utf-8', errors='replace').strip()


def rm_upload_epub(epub_bytes, title, user_token):
    """Upload EPUB using the new sync15 /doc/v2/files API."""
    meta_b64 = base64.b64encode(
        json.dumps({'file_name': title}).encode('utf-8')
    ).decode('ascii')

    data = _post(
        UPLOAD_HOST,
        '/doc/v2/files',
        body=epub_bytes,
        headers={
            'Authorization': 'Bearer ' + user_token,
            'Content-Type':  'application/epub+zip',
            'rm-meta':       meta_b64,
            'rm-source':     'RoR-Browser',
            'User-Agent':    'reMarkable Desktop/3.0.1.5',
            'Content-Length': str(len(epub_bytes)),
        },
    )
    resp = json.loads(data.decode('utf-8', errors='replace'))
    doc_id = resp.get('docID') or resp.get('ID') or resp.get('id')
    if not doc_id:
        raise RuntimeError('Unexpected upload response: {}'.format(resp))
    return doc_id


class SendToRemarkableAction(InterfaceAction):
    name        = 'Send to reMarkable'
    action_spec = ('Send to reMarkable', None,
                   'Send selected books to reMarkable via cloud', None)

    def genesis(self):
        try:
            self.qaction.setIcon(self.get_icons('images/icon.png'))
        except Exception:
            pass
        self.qaction.triggered.connect(self.send_books)

    def apply_settings(self):
        pass

    def send_books(self):
        from calibre.gui2 import error_dialog, info_dialog, question_dialog
        from calibre_plugins.send_to_remarkable.config import prefs

        token = prefs.get('device_token', '')
        if not token:
            error_dialog(self.gui, 'Not configured',
                'Register your device first via Preferences \u2192 Plugins '
                '\u2192 Send to reMarkable \u2192 Customize.', show=True)
            return

        rows = self.gui.library_view.selectionModel().selectedRows()
        if not rows:
            error_dialog(self.gui, 'No books selected',
                         'Select one or more books first.', show=True)
            return

        book_ids = [self.gui.library_view.model().id(r) for r in rows]
        db = self.gui.current_db.new_api

        books, to_convert = [], []
        for bid in book_ids:
            mi   = db.get_metadata(bid)
            fmts = db.formats(bid)
            if not fmts:
                continue
            fmt = 'EPUB' if 'EPUB' in fmts else list(fmts)[0]
            if fmt != 'EPUB':
                to_convert.append(mi.title)
            books.append((bid, mi.title, fmt))

        if not books:
            error_dialog(self.gui, 'Nothing to send',
                         'No format files found.', show=True)
            return

        if to_convert:
            if not question_dialog(self.gui, 'Conversion required',
                'These will be converted to EPUB first:\n\n'
                + '\n'.join('  \u2022 ' + t for t in to_convert) + '\n\nContinue?'):
                return

        try:
            user_token = rm_user_token(token)
        except Exception as e:
            error_dialog(self.gui, 'Auth failed',
                'Could not connect to reMarkable:\n\n{}'.format(e), show=True)
            return

        from qt.core import QProgressDialog, Qt
        progress = QProgressDialog('Sending\u2026', 'Cancel', 0, len(books), self.gui)
        try:
            progress.setWindowModality(Qt.WindowModality.WindowModal)
        except AttributeError:
            progress.setWindowModality(Qt.WindowModal)
        progress.setWindowTitle('Send to reMarkable')
        progress.setValue(0)

        sent, errors = [], []
        for idx, (bid, title, fmt) in enumerate(books):
            if progress.wasCanceled():
                break
            progress.setLabelText('Sending: ' + title)
            progress.setValue(idx)
            try:
                rm_upload_epub(self._get_epub(bid, fmt, db), title, user_token)
                sent.append(title)
            except Exception as exc:
                errors.append('{}: {}'.format(title, exc))
        progress.setValue(len(books))

        parts = []
        if sent:
            parts.append('Sent {}:\n'.format(len(sent))
                         + '\n'.join('  \u2713 ' + t for t in sent))
        if errors:
            parts.append('Errors:\n' + '\n'.join('  \u2717 ' + e for e in errors))

        if errors:
            error_dialog(self.gui, 'Send to reMarkable', '\n\n'.join(parts), show=True)
        else:
            info_dialog(self.gui, 'Send to reMarkable', '\n\n'.join(parts), show=True)

    def _get_epub(self, book_id, fmt, db):
        if fmt == 'EPUB':
            with open(db.format_abspath(book_id, 'EPUB'), 'rb') as fh:
                return fh.read()
        src  = db.format_abspath(book_id, fmt)
        fd, out = tempfile.mkstemp(suffix='.epub')
        os.close(fd)
        try:
            from calibre.ebooks.conversion.plumber import Plumber
            from calibre.utils.logging import Log
            Plumber(src, out, Log()).run()
            with open(out, 'rb') as fh:
                return fh.read()
        finally:
            try:
                os.unlink(out)
            except OSError:
                pass
